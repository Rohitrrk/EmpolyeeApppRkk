package com.cg.emp.dao;

import java.util.ArrayList;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.emp.dto.EmployeeDto;



@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public void addEmployee(EmployeeDto employee) {
		
		entityManager.persist(employee);
		entityManager.flush();
		
	}

	@Override
	public EmployeeDto getInfoByID(int empId) {
		
		//EmployeeDto emp = entityManager.find(EmployeeDto.class,empId);
		
		EmployeeDto emp = new EmployeeDto();
		Query q = entityManager.createNamedQuery("getById");
		q.setParameter("empId", empId);
		emp = (EmployeeDto) q.getSingleResult();
		return emp;
		
		
	}

	@Override
	public List<EmployeeDto> getAllDetails() {
		
	/*	TypedQuery<EmployeeDto> query = entityManager.createQuery("SELECT e FROM EmployeeDto e", EmployeeDto.class);
		return query.getResultList();*/
		Query q = entityManager.createNamedQuery("getAllDetails");
		return q.getResultList(); 
		

	}

	@Override
	public boolean delete(int employeeId) {
		
		EmployeeDto e = getInfoByID(employeeId);
		entityManager.remove(e);
		return true;
	}

	@Override
	public void updateEmployee(EmployeeDto employee) {
		
		entityManager.merge(employee);
		entityManager.flush();
		
		
		
	}

	@Override
	public List<Integer> getId() {
		
		/*TypedQuery<Integer> q=entityManager.createQuery("Select employeeId from EmployeeDto e",Integer.class);
		return  q.getResultList();*/
		Query q = entityManager.createNamedQuery("getId");
		return q.getResultList(); 
		
	}

	
	
	
	
}
