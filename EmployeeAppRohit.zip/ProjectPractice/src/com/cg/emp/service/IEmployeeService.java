package com.cg.emp.service;

import java.util.ArrayList;



import java.util.List;

import com.cg.emp.dto.EmployeeDto;

public interface IEmployeeService {

	void addEmployee(EmployeeDto employee);
	EmployeeDto getInfoByID(int empId);
	List<EmployeeDto> getAllDetails();
	boolean delete(int employeeId);
	void updateEmployee(EmployeeDto employee);
	List<Integer> getId();

	

}
