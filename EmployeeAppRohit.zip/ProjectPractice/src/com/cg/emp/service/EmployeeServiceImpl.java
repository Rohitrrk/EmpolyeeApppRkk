package com.cg.emp.service;

import java.util.ArrayList;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.emp.dao.IEmployeeDao;
import com.cg.emp.dto.EmployeeDto;

@Service
public class EmployeeServiceImpl implements IEmployeeService{

	@Autowired
	IEmployeeDao dao;
	
	public IEmployeeDao getDao() {
		return dao;
	}

	public void setDao(IEmployeeDao dao) {
		this.dao = dao;
	}

	@Override
	public void addEmployee(EmployeeDto employee) {
		dao.addEmployee(employee);
		
	}

	@Override
	public EmployeeDto getInfoByID(int empId) {
		
		return dao.getInfoByID(empId);
	}

	@Override
	public List<EmployeeDto> getAllDetails() {
		
		return dao.getAllDetails();
	}

	@Override
	public boolean delete(int employeeId) {
		
		return dao.delete(employeeId);
	}

	@Override
	public void updateEmployee(EmployeeDto employee) {
		dao.updateEmployee(employee);
		
	}

	@Override
	public List<Integer> getId() {
		
		return dao.getId();
	}

}
