package com.cg.emp.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.emp.dto.EmployeeDto;
import com.cg.emp.service.IEmployeeService;


@Controller
public class MainController {
	@Autowired
	IEmployeeService service;
	
	public IEmployeeService getService() {
		return service;
	}

	public void setService(IEmployeeService service) {
		this.service = service;
	}

	@RequestMapping("/index")
	public String showIndex()
	{	
		return "pages/index";
	}
	
	@RequestMapping("/register")
	public String showRegForm(Model model)
	{
		model.addAttribute("employee", new EmployeeDto());
		return "pages/EmployeeRegForm";
		
	}
	
	@RequestMapping("/addEmployee")
	public ModelAndView addEmployee(@ModelAttribute("employee") @Valid EmployeeDto employee,BindingResult result)
	{
		if(result.hasErrors())
		{
			return new ModelAndView("pages/EmployeeRegForm","emp",employee);
		}
		else
			service.addEmployee(employee);
			return new ModelAndView("pages/insertSuccess");
	}
	

/*	@RequestMapping("/getById")
	public String showGetById(Model model)
	{
		model.addAttribute("employee", new EmployeeDto());
		return "pages/getByIdPage";
		
	}*/
	
	
	@RequestMapping("/getInfoById")
	public ModelAndView getById(@RequestParam("employeeId") String empid)
	{
		System.out.println("in controller get info by id !!!");
		int empId = Integer.parseInt(empid);
		EmployeeDto emp = service.getInfoByID(empId);
		return new ModelAndView("pages/showDataById","emp",emp);
	}
	
	@RequestMapping("/getById")
	public ModelAndView getId(Model model)
	{
		System.out.println("in controller");
		List<Integer> list=service.getId();
		System.out.println(list);
		model.addAttribute("employee", new EmployeeDto());
		return new ModelAndView("pages/getByIdPage","id",list);

	}
	
	@RequestMapping("/getAll")
	public ModelAndView displayAll()
	{
		List<EmployeeDto> empList = service.getAllDetails();
		return new ModelAndView("pages/displayAll","list",empList);
		
	}
	
	
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public String doDelete(@RequestParam int employeeId){
		if(service.delete(employeeId))
			System.out.println("Data Deleted Successfully");
		else
			System.out.println("Not Deleted");
		
		return "redirect:getAll.obj";
	}
	
	@RequestMapping(value="/edit",method=RequestMethod.GET)
	public ModelAndView showEdit(@RequestParam int employeeId){
		
		return new ModelAndView("pages/UpdateForm","employee",service.getInfoByID(employeeId));
	}
	
	
	
	@RequestMapping("/update")
	public ModelAndView updateEmployee(@ModelAttribute("employee") @Valid EmployeeDto employee,BindingResult result)
	{
		service.updateEmployee(employee);
		return new ModelAndView("pages/updateSuccess");
	}
	
	
	
}
